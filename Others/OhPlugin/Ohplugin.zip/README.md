# OpenHarness plugin to do dependency auditing 

This plugin adds `dependency_audit` and the bare `/audit` slash command to OpenHarness. It reads `requirements.txt` and `package.json` files directly inside a selected folder, checks exact versions and supported npm ranges against OSV.dev, and reports structured findings. It never installs packages or edits project files. `/audit summary` returns the most recent audit held in the current OpenHarness session.

Exact versions are queried directly. For supported npm ranges (`^`, `~`, partial/wildcard versions, and basic `>=`/`<` comparator ranges), the plugin queries OSV without a version and checks the returned affected versions/ranges locally. A finding reports the lowest matching affected version as a candidate plus the declared range; it does not claim that candidate is installed. Unsupported ranges, URLs, tags, includes, editable installs, and other unsupported requirement forms are reported as skipped, making the result `incomplete` instead of silently treating them as clean. Advisory severity uses a recognized OSV `database_specific.severity` first (`MODERATE` maps to `MEDIUM`), then calculates the base score from a complete CVSS v3.0/v3.1 vector and buckets it (`CRITICAL` ≥9.0, `HIGH` ≥7.0, `MEDIUM` ≥4.0, otherwise `LOW`). Unavailable or invalid severity remains `UNKNOWN`; the original CVSS data is retained in the result when present.

## Use with upstream OpenHarness

The current upstream plugin loader prefixes plugin commands. This project includes a small OpenHarness patch that allows an individual Markdown plugin command to opt into a bare command name. The patch is pinned to upstream commit `9b2efd795c6aa09f88b0c257d269a9e518da6ae7`.

For a Windows checkout, run `setup.ps1` from this plugin repository. It prompts for the OpenHarness checkout, checks and applies the patch (or detects that it is already applied), copies the plugin into that checkout's `.openharness/plugins`, and enables project plugins plus `dependency_audit` in the user's `~/.openharness/settings.json`. If a plugin copy already exists, the script asks before replacing it. Git changes are not reverted by the setup script.

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup.ps1
```

On Linux, run the Bash version from this plugin repository. It requires `git` and `python3`:

```bash
bash setup.sh
```

Both scripts preserve unrelated settings. The Linux script also honors `OPENHARNESS_CONFIG_DIR` when set, matching OpenHarness's config path behavior.

OpenHarness reads `allow_project_plugins` and `enabled_plugins` from the user settings file, while it discovers project plugins from the `.openharness/plugins` directory under its working directory.

```powershell
git clone https://github.com/HKUDS/OpenHarness.git
cd OpenHarness
git checkout 9b2efd795c6aa09f88b0c257d269a9e518da6ae7
git apply --check C:\path\to\OhPlugin\patches\openharness-bare-plugin-commands.patch
git apply C:\path\to\OhPlugin\patches\openharness-bare-plugin-commands.patch
```

Install that checkout using its normal development instructions. Copy this plugin folder into the project where `oh` will run:

```powershell
New-Item -ItemType Directory -Force .openharness\plugins | Out-Null
Copy-Item -Recurse C:\path\to\OhPlugin\.openharness\plugins\dependency_audit .openharness\plugins\
```

Project plugins are disabled by default. In `~/.openharness/settings.json` (on Windows, typically `$HOME\.openharness\settings.json`), set:

```json
{
  "allow_project_plugins": true,
  "enabled_plugins": {
    "dependency_audit": true
  }
}
```

Then start `oh` from the project directory. The command is registered in the OpenHarness command picker and can be invoked as:

```text
/audit .
/audit path\to\project
/audit summary
```

The command submits a focused prompt to the running agent, which calls the plugin tool through OpenHarness's normal tool execution and permission checks. Relative paths stay under the current project directory; absolute paths may target another folder. Resolved manifest files are checked against OpenHarness path rules and any active Docker sandbox boundary, including symlink resolution. The audit makes HTTPS calls only to the fixed OSV API host, with bounded timeouts, response sizes, and package/advisory counts.

## Running tests

Run the unit tests and the OpenHarness CLI integration test from the plugin repository root. The Python environment needs `pytest`, `pytest-asyncio`, and the OpenHarness dependencies. The integration test runs `uv run oh --dry-run` from the OpenHarness checkout; set `OPENHARNESS_REPO` if that checkout is not at `../OpenHarness` relative to this repository.

```powershell
python -m pytest tests/unit tests/integration
```

The integration test does not invoke a model. Its successful run prints a green check. To run the interactive end-to-end check separately, use:

```powershell
python tests/e2e/run_manual_audit_e2e.py
```

The E2E script prompts for the OhPlugin folder path and runs `uv run oh -p "/audit <path>"` from the OpenHarness checkout. It uses the configured OpenHarness model and may make a live model request. It passes when the CLI output contains the expected message that no supported manifest was found; successful completion prints a green check. Set `OPENHARNESS_REPO` before running it if the checkout is elsewhere.

## Scope and limitations

- Only root-level `requirements.txt` and `package.json` are read; this is not recursive discovery.
- Python requirements must still be pinned exactly. npm ranges are checked against OSV affected-version data for overlap, but this does not resolve the installed version; lockfiles are needed for that. Dependency resolution and transitive dependencies remain out of scope.
- OSV batch results are enriched with advisory records so aliases and available severity data can be returned. Missing or invalid severity is `UNKNOWN`.
- `/audit summary` is scoped to the current in-memory session and is not persisted across restarts.
- The OpenHarness patch is a compatibility bridge. A released upstream command-alias feature would remove the need to apply it.

## OpenHarness patch contents

The patch adds the `openharness-command` Markdown frontmatter field, protects built-in command names from plugin replacement, and gives tools access to mutable session state for the summary feature. It includes focused tests for command registration and collision behavior.
